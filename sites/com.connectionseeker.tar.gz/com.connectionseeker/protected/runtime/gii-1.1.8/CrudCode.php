<?php
return array (
  'template' => 'linkUI',
  'baseControllerClass' => 'Controller',
);
