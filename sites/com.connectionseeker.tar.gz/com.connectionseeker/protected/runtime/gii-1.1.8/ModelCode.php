<?php
return array (
  'template' => 'default',
  'tablePrefix' => 'lkm_',
  'modelPath' => 'application.models',
  'baseClass' => 'CActiveRecord',
  'buildRelations' => '1',
);
