<?php $this->beginContent('//layouts/main'); ?>
<div class="tdsize">
  <?php echo $content; ?>
</div><!-- content -->
<?php $this->endContent(); ?>